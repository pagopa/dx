const { app } = require("@azure/functions");

app.get("health", async () => ({
  statusCode: 200,
  jsonBody: {
    message: "it works!"
  }
}))